import type { Config } from 'tailwindcss'
const c = (n: string) => `rgb(var(--${n}) / <alpha-value>)`
export default {
  darkMode: 'class',
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { paper: c('paper'), surface: c('surface'), ink: c('ink'), pine: c('pine'), leaf: c('leaf'), onleaf: c('onleaf'), line: c('line') },
    fontFamily: { sans: ['var(--font-sans)', 'system-ui', 'sans-serif'] },
  } },
} satisfies Config
