alter type lead_status add value if not exists 'converted';
create type channel_kind as enum ('email', 'social', 'paid_ads');
create type post_status as enum ('draft', 'scheduled', 'published');
alter table campaigns add column channel channel_kind not null default 'social';
alter table leads add column tags text[] not null default '{}';

create table posts (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations on delete cascade,
  campaign_id uuid references campaigns on delete set null,
  title text not null, body text not null default '',
  channel channel_kind not null default 'social',
  status post_status not null default 'draft',
  scheduled_at timestamptz,
  created_by uuid default auth.uid() references profiles(id),
  created_at timestamptz not null default now()
);
create index on posts (org_id, status);
alter table posts enable row level security;
create policy "members read posts" on posts for select using (org_role_of(org_id) is not null);
create policy "staff write posts" on posts for all
  using (org_role_of(org_id) in ('admin', 'member')) with check (org_role_of(org_id) in ('admin', 'member'));
