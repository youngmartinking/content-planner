-- Enums
create type org_role as enum ('admin', 'member', 'client');
create type campaign_status as enum ('draft', 'active', 'paused', 'completed');
create type lead_status as enum ('new', 'contacted', 'qualified', 'won', 'lost');

-- Tables
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  email text, full_name text, avatar_url text,
  created_at timestamptz not null default now()
);
create table organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null, industry text, target_audience text, brand_voice text,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);
create table memberships (
  org_id uuid references organizations on delete cascade,
  user_id uuid references profiles on delete cascade,
  role org_role not null default 'member',
  primary key (org_id, user_id)
);
create table campaigns (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations on delete cascade,
  name text not null,
  status campaign_status not null default 'draft',
  platforms text[] not null default '{}',
  starts_on date, ends_on date,
  created_by uuid default auth.uid() references profiles(id),
  created_at timestamptz not null default now()
);
create table leads (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations on delete cascade,
  campaign_id uuid references campaigns on delete set null,
  name text not null, email text, phone text, source text, notes text,
  status lead_status not null default 'new',
  created_by uuid default auth.uid() references profiles(id),
  created_at timestamptz not null default now()
);
create index on memberships (user_id);
create index on campaigns (org_id);
create index on leads (org_id, status);

-- Role lookup used by every policy (security definer avoids RLS recursion)
create function org_role_of(o uuid) returns org_role
language sql stable security definer set search_path = public as $$
  select role from memberships where org_id = o and user_id = auth.uid()
$$;

-- Profile row on signup (email or Google)
create function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name, avatar_url) values (
    new.id, new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Onboarding: create org and make the caller its admin in one step
create function create_organization(p_name text, p_industry text, p_audience text, p_voice text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid;
begin
  insert into organizations (name, industry, target_audience, brand_voice, created_by)
  values (p_name, p_industry, p_audience, p_voice, auth.uid()) returning id into v;
  insert into memberships (org_id, user_id, role) values (v, auth.uid(), 'admin');
  return v;
end $$;

-- Row level security
alter table profiles enable row level security;
alter table organizations enable row level security;
alter table memberships enable row level security;
alter table campaigns enable row level security;
alter table leads enable row level security;

create policy "own profile" on profiles for all using (id = auth.uid());
create policy "members read org" on organizations for select using (org_role_of(id) is not null);
create policy "admins edit org" on organizations for update using (org_role_of(id) = 'admin');
create policy "members read memberships" on memberships for select using (org_role_of(org_id) is not null);
create policy "admins manage memberships" on memberships for all using (org_role_of(org_id) = 'admin');
-- Clients can view campaigns but never touch leads
create policy "members read campaigns" on campaigns for select using (org_role_of(org_id) is not null);
create policy "staff write campaigns" on campaigns for all
  using (org_role_of(org_id) in ('admin', 'member')) with check (org_role_of(org_id) in ('admin', 'member'));
create policy "staff manage leads" on leads for all
  using (org_role_of(org_id) in ('admin', 'member')) with check (org_role_of(org_id) in ('admin', 'member'));
