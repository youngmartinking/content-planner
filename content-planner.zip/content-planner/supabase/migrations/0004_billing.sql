create table subscriptions (
  org_id uuid primary key references organizations on delete cascade,
  plan text,
  status text not null default 'inactive' check (status in ('inactive', 'active', 'past_due', 'cancelled')),
  provider text not null default 'paystack',
  provider_customer text, provider_subscription text,
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);
create index on subscriptions (provider_customer);
alter table subscriptions enable row level security;
create policy "members read subscription" on subscriptions for select using (org_role_of(org_id) is not null);
-- No insert/update policies on purpose: only the server (service role) writes, from the verified webhook.
