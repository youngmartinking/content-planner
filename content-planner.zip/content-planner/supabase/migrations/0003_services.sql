alter table organizations add column services text[] not null default '{}';
drop function create_organization(text, text, text, text);
create function create_organization(p_name text, p_industry text, p_audience text, p_voice text, p_services text[] default '{}')
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid;
begin
  insert into organizations (name, industry, target_audience, brand_voice, services, created_by)
  values (p_name, p_industry, p_audience, p_voice, p_services, auth.uid()) returning id into v;
  insert into memberships (org_id, user_id, role) values (v, auth.uid(), 'admin');
  return v;
end $$;
