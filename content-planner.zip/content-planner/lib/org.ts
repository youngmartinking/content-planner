import { redirect } from 'next/navigation'
import { createClient } from './supabase/server'
import type { Role } from './permissions'

export type Org = { id: string; name: string; industry: string | null; target_audience: string | null; brand_voice: string | null; services: string[] }

export async function getContext() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')
  const { data: m } = await supabase.from('memberships')
    .select('role, organizations(id, name, industry, target_audience, brand_voice, services)')
    .eq('user_id', user.id).limit(1).maybeSingle()
  if (!m) redirect('/onboarding')
  return { supabase, user, role: m.role as Role, org: m.organizations as unknown as Org }
}
