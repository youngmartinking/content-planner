import { createClient } from '@supabase/supabase-js'
// Service-role client: bypasses RLS. Import only from server routes such as the payment webhook.
export const createAdminClient = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } })
