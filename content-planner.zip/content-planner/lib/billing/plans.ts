export type Plan = { key: string; name: string; price: number; currency: 'GHS'; blurb: string; paystackPlan?: string }

// Placeholder names and prices. Each price must match the plan you create in the Paystack dashboard.
export const PLANS: Plan[] = [
  { key: 'starter', name: 'Starter', price: 500, currency: 'GHS', blurb: 'Social media management and handle upkeep.', paystackPlan: process.env.PAYSTACK_PLAN_STARTER },
  { key: 'growth', name: 'Growth', price: 1200, currency: 'GHS', blurb: 'Adds branding, graphic design and PR.', paystackPlan: process.env.PAYSTACK_PLAN_GROWTH },
  { key: 'scale', name: 'Scale', price: 2500, currency: 'GHS', blurb: 'Adds video production and web development.', paystackPlan: process.env.PAYSTACK_PLAN_SCALE },
]
