import type { BillingProvider } from './provider'

export const paystack: BillingProvider = {
  name: 'paystack',
  async checkout({ email, plan, orgId, callbackUrl }) {
    if (!plan.paystackPlan) throw new Error(`Missing Paystack plan code for ${plan.key}`)
    const res = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email, amount: plan.price * 100, currency: plan.currency, plan: plan.paystackPlan,
        callback_url: callbackUrl, metadata: { org_id: orgId, plan: plan.key },
      }),
    })
    const json = await res.json()
    if (!res.ok || !json.status) throw new Error(json.message ?? 'Paystack error')
    return json.data.authorization_url as string
  },
}
