import type { Plan } from './plans'
import { paystack } from './paystack'

// Add another provider (for example Flutterwave) by implementing this type and switching it here.
export type BillingProvider = {
  name: string
  checkout(args: { email: string; plan: Plan; orgId: string; callbackUrl: string }): Promise<string>
}
export const provider: BillingProvider = paystack
