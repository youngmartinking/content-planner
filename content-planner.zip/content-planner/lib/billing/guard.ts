import { redirect } from 'next/navigation'
import type { getContext } from '@/lib/org'
import { can, type Role } from '@/lib/permissions'

type Db = Awaited<ReturnType<typeof getContext>>['supabase']

// Locks a page until the organization has an active plan. Off unless BILLING_ENFORCED=true.
export async function requirePlan(supabase: Db, orgId: string, role: Role) {
  if (process.env.BILLING_ENFORCED !== 'true') return
  const { data } = await supabase.from('subscriptions').select('status').eq('org_id', orgId).maybeSingle()
  if (data?.status !== 'active') redirect(can.manageBilling(role) ? '/billing' : '/dashboard')
}
