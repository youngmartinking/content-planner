export type Role = 'admin' | 'member' | 'client'
// One place to change who can do what. RLS enforces the same rules in the database.
export const can = {
  manageTeam: (r: Role) => r === 'admin',
  manageBilling: (r: Role) => r === 'admin',
  editContent: (r: Role) => r !== 'client',
  viewLeads: (r: Role) => r !== 'client',
}
