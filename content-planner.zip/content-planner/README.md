# Indigo Workspace

Client workspace for Indigo Incorporated: one monthly plan for brand, handle, PR, design, video and web. The logo is a vector redraw in `components/Logo.tsx` (swap in the original SVG there if you have one).

## Constraints (stack and style)
- **Frontend:** Next.js 14 (App Router), React 18, TypeScript (strict), Tailwind CSS 3 with class-based dark mode and CSS-variable colour tokens. No UI or chart library; the chart is inline SVG.
- **Backend:** Next.js server components and route handlers. Supabase Auth (email/password and Google). Authorisation is enforced by Postgres row level security, not only in the UI.
- **Runtime:** Node.js 24 (set in `package.json` engines and `.nvmrc`).
- **Database:** Supabase Postgres, schema managed as SQL migrations in `supabase/migrations`.
- **Style:** minimalist and corporate-clean, light and dark themes with a toggle, AA contrast, short transitions that respect reduced-motion settings.
- **Performance:** data is fetched in server components; client components are used only where there is interaction. Navigation uses `next/link` prefetching, filtering is client-side with `useDeferredValue`, and each route shows a loading skeleton.

## Setup
1. Create a Supabase project and run `0001_init.sql`, `0002_modules.sql`, `0003_services.sql`, then `0004_billing.sql` in the SQL editor.
2. Authentication > Providers: enable Email and Google (add your Google OAuth client ID and secret).
3. Authentication > URL Configuration: add `http://localhost:3000/auth/callback` to Redirect URLs.
4. `cp .env.example .env.local` and fill in your project URL and anon key.
5. `npm install && npm run dev`

## Modules
- **Overview:** KPI cards (active campaigns, total leads, conversion rate) and an 8-week leads-and-conversions chart. Clients see campaigns only.
- **Campaigns:** board by stage (draft, active, paused, completed), tagged Email, Social or Paid ads.
- **Content:** post editor with character limits per channel, campaign tag, and draft, scheduled or published status.
- **Leads:** search, status and source filters, tags, inline status changes, and CSV export of the filtered rows (opens in Excel).
- Not included yet: calendar view, AI-assisted drafting, rich-text formatting, CSV import, team invites (add a row to `memberships` for now).

## Payments (Paystack)
1. In the Paystack dashboard, create three monthly plans in GHS and copy their codes into `PAYSTACK_PLAN_STARTER`, `_GROWTH` and `_SCALE`. The names and prices in `lib/billing/plans.ts` are placeholders and each price must match its Paystack plan, or the webhook will ignore the payment.
2. Put your test secret key in `PAYSTACK_SECRET_KEY`, and your Supabase service-role key in `SUPABASE_SERVICE_ROLE_KEY`. Both are server-only; never prefix them with `NEXT_PUBLIC_`.
3. In Paystack under Settings > API Keys & Webhooks, set the webhook URL to `https://YOUR-DOMAIN/api/billing/webhook`. Locally, expose port 3000 with a tunnel such as ngrok.
4. Admins pay from the Billing page. Plans activate only when the signed webhook arrives, not from the browser redirect.
5. Set `BILLING_ENFORCED=true` to lock Campaigns, Content and Leads until a plan is active. It is off by default so you can build and test first.
6. Another provider (for example Flutterwave) plugs in by implementing `BillingProvider` in `lib/billing/provider.ts`.
