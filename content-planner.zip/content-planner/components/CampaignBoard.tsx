'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { CAMPAIGN_STAGES, CHANNELS, type Campaign } from '@/lib/types'

export default function CampaignBoard({ initial, orgId, canEdit }: { initial: Campaign[]; orgId: string; canEdit: boolean }) {
  const supabase = createClient()
  const [items, setItems] = useState(initial)
  const [err, setErr] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)

  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget, d = new FormData(form), name = String(d.get('name')).trim()
    if (name.length < 2) return setErr({ name: 'Name the campaign with at least 2 characters.' })
    setBusy(true)
    const { data, error } = await supabase.from('campaigns')
      .insert({ org_id: orgId, name, channel: d.get('channel'), starts_on: d.get('starts_on') || null })
      .select('id, name, channel, status, starts_on').single()
    setBusy(false)
    if (error) return setErr({ form: error.message })
    setItems([data as Campaign, ...items]); setErr({}); form.reset()
  }
  async function move(id: string, status: Campaign['status']) {
    const prev = items
    setItems(items.map((c) => (c.id === id ? { ...c, status } : c)))
    const { error } = await supabase.from('campaigns').update({ status }).eq('id', id)
    if (error) { setItems(prev); setErr({ form: error.message }) }
  }

  return (
    <div className="mt-6 space-y-8">
      {canEdit && (
        <form onSubmit={create} noValidate className="flex flex-wrap items-start gap-2">
          <div>
            <input name="name" className="input" placeholder="Campaign name" aria-label="Campaign name" aria-invalid={!!err.name} />
            {err.name && <p role="alert" className="err">{err.name}</p>}
          </div>
          <select name="channel" className="input w-auto" aria-label="Channel">
            {Object.entries(CHANNELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <input name="starts_on" type="date" className="input w-auto" aria-label="Start date" />
          <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create campaign'}</button>
          {err.form && <p role="alert" className="err w-full">{err.form}</p>}
        </form>
      )}
      {items.length === 0 ? (
        <div className="rounded-lg border border-dashed border-line p-10 text-center">
          <p className="text-lg font-medium">No campaigns yet</p>
          <p className="mt-1 text-ink/70">{canEdit ? 'Name your first campaign above and choose the channel it runs on.' : 'Your team hasn’t shared any campaigns yet.'}</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {CAMPAIGN_STAGES.map((stage) => {
            const col = items.filter((c) => c.status === stage)
            return (
              <section key={stage} aria-label={stage}>
                <h2 className="mb-2 text-sm font-medium capitalize text-ink/70">{stage} ({col.length})</h2>
                <ul className="space-y-2">
                  {col.map((c) => (
                    <li key={c.id} className="rounded-lg border border-line bg-surface p-3 transition-shadow hover:shadow-md">
                      <p className="font-medium">{c.name}</p>
                      <p className="mt-1 text-sm text-ink/70">{CHANNELS[c.channel]}{c.starts_on ? `, starts ${c.starts_on}` : ''}</p>
                      {canEdit && (
                        <select value={c.status} onChange={(e) => move(c.id, e.target.value as Campaign['status'])} aria-label={`Move ${c.name}`} className="input mt-2 py-1">
                          {CAMPAIGN_STAGES.map((s) => <option key={s}>{s}</option>)}
                        </select>
                      )}
                    </li>
                  ))}
                </ul>
              </section>
            )
          })}
        </div>
      )}
    </div>
  )
}
