'use client'
import { useEffect, useState } from 'react'

export default function ThemeToggle() {
  const [dark, setDark] = useState(false)
  useEffect(() => setDark(document.documentElement.classList.contains('dark')), [])
  function toggle() {
    const d = !dark
    setDark(d); document.documentElement.classList.toggle('dark', d)
    try { localStorage.theme = d ? 'dark' : 'light' } catch {}
  }
  return <button onClick={toggle} aria-pressed={dark} className="mt-2 block text-white/80 underline">{dark ? 'Light mode' : 'Dark mode'}</button>
}
