'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { CHANNELS, POST_STATUSES, type Channel, type Post } from '@/lib/types'

const LIMIT: Record<Channel, number> = { social: 3000, email: 10000, paid_ads: 150 }
const blank = { id: '', title: '', body: '', channel: 'social' as Channel, status: 'draft' as Post['status'], scheduled_at: '', campaign_id: '' }
const toLocal = (iso: string) => { const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16) }

export default function PostEditor({ initial, campaigns, orgId, canEdit }: { initial: Post[]; campaigns: { id: string; name: string }[]; orgId: string; canEdit: boolean }) {
  const supabase = createClient()
  const [posts, setPosts] = useState(initial)
  const [f, setF] = useState(blank)
  const [errs, setErrs] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const up = <K extends keyof typeof blank>(k: K, v: (typeof blank)[K]) => setF({ ...f, [k]: v })
  const open = (p: Post) => { setErrs({}); setF({ id: p.id, title: p.title, body: p.body, channel: p.channel, status: p.status, scheduled_at: p.scheduled_at ? toLocal(p.scheduled_at) : '', campaign_id: p.campaign_id ?? '' }) }

  async function save(e: React.FormEvent) {
    e.preventDefault()
    const v: Record<string, string> = {}
    if (!f.title.trim()) v.title = 'Add a title so you can find this post later.'
    if (!f.body.trim()) v.body = 'Write some copy before saving.'
    else if (f.body.length > LIMIT[f.channel]) v.body = `This channel allows ${LIMIT[f.channel]} characters.`
    if (f.status === 'scheduled' && (!f.scheduled_at || new Date(f.scheduled_at) <= new Date())) v.scheduled_at = 'Pick a date and time in the future.'
    setErrs(v)
    if (Object.keys(v).length) return
    setBusy(true)
    const row = { title: f.title.trim(), body: f.body, channel: f.channel, status: f.status, campaign_id: f.campaign_id || null, scheduled_at: f.status === 'scheduled' ? new Date(f.scheduled_at).toISOString() : null }
    const q = f.id ? supabase.from('posts').update(row).eq('id', f.id) : supabase.from('posts').insert({ ...row, org_id: orgId })
    const { data, error } = await q.select('id, title, body, channel, status, scheduled_at, campaign_id').single()
    setBusy(false)
    if (error) return setErrs({ form: error.message })
    const saved = data as Post
    setPosts(f.id ? posts.map((p) => (p.id === f.id ? saved : p)) : [saved, ...posts]); setF({ ...f, id: saved.id })
  }

  return (
    <div className="mt-6 grid gap-8 lg:grid-cols-[16rem_1fr]">
      <aside>
        {canEdit && <button className="btn-ghost mb-3 w-full" onClick={() => { setF(blank); setErrs({}) }}>New post</button>}
        {posts.length === 0
          ? <p className="rounded-lg border border-dashed border-line p-4 text-sm text-ink/70">No posts yet. Draft your first one and tag it to a campaign.</p>
          : <ul className="divide-y divide-line border-y border-line">
              {posts.map((p) => (
                <li key={p.id}><button onClick={() => open(p)} aria-current={p.id === f.id} className={`w-full px-2 py-3 text-left transition-colors hover:bg-surface ${p.id === f.id ? 'bg-surface' : ''}`}>
                  <span className="block truncate font-medium">{p.title}</span><span className="text-sm text-ink/70">{CHANNELS[p.channel]}, {p.status}</span>
                </button></li>
              ))}
            </ul>}
      </aside>
      <form onSubmit={save} noValidate>
        <fieldset disabled={!canEdit} className="space-y-4">
          <div>
            <input className="input" placeholder="Post title" aria-label="Title" value={f.title} onChange={(e) => up('title', e.target.value)} />
            {errs.title && <p role="alert" className="err">{errs.title}</p>}
          </div>
          <div className="flex flex-wrap gap-2">
            <select className="input w-auto" aria-label="Channel" value={f.channel} onChange={(e) => up('channel', e.target.value as Channel)}>
              {Object.entries(CHANNELS).map(([k, n]) => <option key={k} value={k}>{n}</option>)}
            </select>
            <select className="input w-auto" aria-label="Campaign" value={f.campaign_id} onChange={(e) => up('campaign_id', e.target.value)}>
              <option value="">No campaign</option>{campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <select className="input w-auto" aria-label="Status" value={f.status} onChange={(e) => up('status', e.target.value as Post['status'])}>
              {POST_STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
            {f.status === 'scheduled' && <input type="datetime-local" className="input w-auto" aria-label="Publish time" value={f.scheduled_at} onChange={(e) => up('scheduled_at', e.target.value)} />}
          </div>
          {errs.scheduled_at && <p role="alert" className="err">{errs.scheduled_at}</p>}
          <div>
            <textarea className="input min-h-64 leading-relaxed" placeholder="Write your copy…" aria-label="Body" value={f.body} onChange={(e) => up('body', e.target.value)} />
            <p className={`mt-1 text-right text-sm ${f.body.length > LIMIT[f.channel] ? 'text-red-700 dark:text-red-400' : 'text-ink/70'}`}>{f.body.length} / {LIMIT[f.channel]}</p>
            {errs.body && <p role="alert" className="err">{errs.body}</p>}
          </div>
          {errs.form && <p role="alert" className="err">{errs.form}</p>}
          {canEdit && <button className="btn" disabled={busy}>{busy ? 'Saving…' : f.id ? 'Save changes' : 'Save post'}</button>}
        </fieldset>
      </form>
    </div>
  )
}
