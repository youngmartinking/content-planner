'use client'
import { useDeferredValue, useMemo, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { downloadCsv } from '@/lib/csv'
import { LEAD_STATUSES, type Lead } from '@/lib/types'

export default function LeadsTable({ initial, orgId, canEdit }: { initial: Lead[]; orgId: string; canEdit: boolean }) {
  const supabase = createClient()
  const [leads, setLeads] = useState(initial)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [source, setSource] = useState('')
  const [errs, setErrs] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const dq = useDeferredValue(q).trim().toLowerCase()
  const sources = useMemo(() => [...new Set(leads.map((l) => l.source).filter(Boolean))] as string[], [leads])
  const rows = useMemo(() => leads.filter((l) =>
    (!status || l.status === status) && (!source || l.source === source) &&
    (!dq || [l.name, l.email, ...l.tags].some((s) => s?.toLowerCase().includes(dq)))), [leads, status, source, dq])

  async function add(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget, d = new FormData(form)
    const name = String(d.get('name')).trim(), email = String(d.get('email')).trim()
    const v: Record<string, string> = {}
    if (!name) v.name = 'Enter the lead’s name.'
    if (email && !/^\S+@\S+\.\S+$/.test(email)) v.email = 'Enter a valid email, like name@company.com.'
    setErrs(v)
    if (Object.keys(v).length) return
    const tags = String(d.get('tags')).split(',').map((t) => t.trim()).filter(Boolean)
    setBusy(true)
    const { data, error } = await supabase.from('leads').insert({ org_id: orgId, name, email: email || null, source: String(d.get('source')).trim() || null, tags })
      .select('id, name, email, source, status, tags, created_at').single()
    setBusy(false)
    if (error) return setErrs({ form: error.message })
    setLeads([data as Lead, ...leads]); form.reset()
  }
  async function setLeadStatus(id: string, s: string) {
    const prev = leads
    setLeads(leads.map((l) => (l.id === id ? { ...l, status: s } : l)))
    const { error } = await supabase.from('leads').update({ status: s }).eq('id', id)
    if (error) { setLeads(prev); setErrs({ form: error.message }) }
  }
  const exportCsv = () => downloadCsv('leads.csv', rows.map((l) => ({ name: l.name, email: l.email, source: l.source, status: l.status, tags: l.tags.join('; '), created: l.created_at.slice(0, 10) })))

  return (
    <div className="mt-6 space-y-6">
      {canEdit && (
        <form onSubmit={add} noValidate className="flex flex-wrap items-start gap-2">
          <div><input name="name" className="input" placeholder="Name" aria-label="Name" />{errs.name && <p role="alert" className="err">{errs.name}</p>}</div>
          <div><input name="email" className="input" placeholder="Email" aria-label="Email" />{errs.email && <p role="alert" className="err">{errs.email}</p>}</div>
          <input name="source" className="input w-auto" placeholder="Source" aria-label="Source" />
          <input name="tags" className="input w-auto" placeholder="Tags, comma separated" aria-label="Tags" />
          <button className="btn" disabled={busy}>{busy ? 'Adding…' : 'Add lead'}</button>
          {errs.form && <p role="alert" className="err w-full">{errs.form}</p>}
        </form>
      )}
      {leads.length === 0 ? (
        <div className="rounded-lg border border-dashed border-line p-10 text-center">
          <p className="text-lg font-medium">No leads yet</p>
          <p className="mt-1 text-ink/70">{canEdit ? 'Add a lead above. Source and tags help you see which campaigns bring people in.' : 'No leads have been added yet.'}</p>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap gap-2">
            <input type="search" className="input max-w-xs" placeholder="Search name, email or tag" aria-label="Search leads" value={q} onChange={(e) => setQ(e.target.value)} />
            <select className="input w-auto" aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">All statuses</option>{LEAD_STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
            <select className="input w-auto" aria-label="Filter by source" value={source} onChange={(e) => setSource(e.target.value)}>
              <option value="">All sources</option>{sources.map((s) => <option key={s}>{s}</option>)}
            </select>
            <button className="btn-ghost ml-auto" onClick={exportCsv} disabled={!rows.length}>Export CSV ({rows.length})</button>
          </div>
          {rows.length === 0 ? <p className="py-8 text-center text-ink/70">No leads match these filters.</p> : (
            <div className="overflow-x-auto rounded-lg border border-line bg-surface">
              <table className="w-full min-w-[40rem] text-left text-sm">
                <thead className="border-b border-line text-ink/70"><tr><th className="p-3 font-medium">Name</th><th className="p-3 font-medium">Source</th><th className="p-3 font-medium">Tags</th><th className="p-3 font-medium">Status</th></tr></thead>
                <tbody className="divide-y divide-line">
                  {rows.map((l) => (
                    <tr key={l.id} className="transition-colors hover:bg-paper">
                      <td className="p-3"><span className="font-medium">{l.name}</span><span className="block text-ink/70">{l.email}</span></td>
                      <td className="p-3">{l.source}</td>
                      <td className="p-3"><div className="flex flex-wrap gap-1">{l.tags.map((t) => <span key={t} className="rounded-full border border-line px-2 py-0.5 text-xs">{t}</span>)}</div></td>
                      <td className="p-3">{canEdit
                        ? <select className="input w-auto py-1" aria-label={`Status for ${l.name}`} value={l.status} onChange={(e) => setLeadStatus(l.id, e.target.value)}>{LEAD_STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
                        : l.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  )
}
