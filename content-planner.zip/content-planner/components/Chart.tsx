export type Point = { label: string; leads: number; converted: number }

// Dependency-free SVG chart: bars = new leads, line = conversions.
export default function Chart({ data }: { data: Point[] }) {
  const W = 600, H = 200, step = W / data.length
  const max = Math.max(1, ...data.map((d) => d.leads))
  const y = (v: number) => H - (v / max) * (H - 10)
  const line = data.map((d, i) => `${i * step + step / 2},${y(d.converted)}`).join(' ')
  return (
    <svg viewBox={`0 0 ${W} ${H + 24}`} role="img" aria-label="New leads and conversions per week" className="w-full">
      {data.map((d, i) => (
        <g key={d.label}>
          <rect x={i * step + step * 0.2} y={y(d.leads)} width={step * 0.6} height={H - y(d.leads)} rx="3" className="fill-leaf/30 transition-colors hover:fill-leaf/60">
            <title>{`${d.label}: ${d.leads} leads, ${d.converted} converted`}</title>
          </rect>
          <text x={i * step + step / 2} y={H + 16} textAnchor="middle" className="fill-ink/70 text-[11px]">{d.label}</text>
        </g>
      ))}
      <polyline points={line} fill="none" strokeWidth="2.5" strokeLinejoin="round" className="stroke-leaf" />
    </svg>
  )
}
