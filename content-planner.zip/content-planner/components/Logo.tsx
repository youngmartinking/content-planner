// Vector redraw of the Indigo Incorporated logo. Wordmark follows currentColor; the swoosh is fixed blue.
export default function Logo({ className = 'h-8', title = 'Indigo Incorporated' }: { className?: string; title?: string }) {
  return (
    <svg viewBox="0 0 910 340" role="img" aria-label={title} className={className} fill="none">
      <defs>
        <linearGradient id="indigo-swoosh" x1="538" y1="264" x2="710" y2="174" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E90FF" /><stop offset="1" stopColor="#3B6BFF" />
        </linearGradient>
      </defs>
      <g stroke="currentColor" strokeWidth="47">
        <path d="M23.5 58V236M488.5 58V236M421.5 0V236" />
        <path d="M90 236V148a67 67 0 0 1 134 0V236" />
        <circle cx="356" cy="147" r="65.5" />
        <circle cx="621" cy="147" r="65.5" />
        <path d="M686.5 58V262a70 70 0 0 1-100 52" />
        <circle cx="819" cy="147" r="65.5" />
      </g>
      <g fill="currentColor"><circle cx="23.5" cy="26" r="26" /><circle cx="488.5" cy="26" r="26" /></g>
      <path d="M538 264C600 232 660 192 710 174V216C660 226 600 244 538 264Z" fill="url(#indigo-swoosh)" />
      <text x="0" y="306" fontSize="42" fontWeight="500" textLength="540" lengthAdjust="spacing" fill="currentColor" style={{ fontFamily: 'var(--font-sans), sans-serif' }}>INCORPORATED</text>
    </svg>
  )
}
