'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import Logo from './Logo'
import ThemeToggle from './ThemeToggle'
import { can, type Role } from '@/lib/permissions'

const NAV: { href: string; label: string; show: (r: Role) => boolean }[] = [
  { href: '/dashboard', label: 'Overview', show: () => true },
  { href: '/campaigns', label: 'Campaigns', show: () => true },
  { href: '/content', label: 'Content', show: () => true },
  { href: '/leads', label: 'Leads', show: can.viewLeads },
  { href: '/billing', label: 'Billing', show: can.manageBilling },
]

export default function Sidebar({ orgName, role, email }: { orgName: string; role: Role; email: string }) {
  const path = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)
  async function signOut() { await createClient().auth.signOut(); router.push('/login'); router.refresh() }

  return (
    <>
      <header className="flex items-center justify-between bg-pine px-4 py-3 text-white lg:hidden">
        <Logo className="h-7" />
        <button onClick={() => setOpen(!open)} aria-expanded={open} className="rounded px-2 py-1 focus-visible:ring-2 focus-visible:ring-white/50">
          {open ? 'Close' : 'Menu'}
        </button>
      </header>
      <aside className={`${open ? 'block' : 'hidden'} bg-pine text-white lg:sticky lg:top-0 lg:flex lg:h-screen lg:w-64 lg:shrink-0 lg:flex-col`}>
        <div className="hidden px-6 py-6 lg:block"><Logo className="h-9" /><p className="mt-5 truncate text-sm text-white/70">{orgName}</p></div>
        <nav className="flex-1 space-y-1 px-3 py-2">
          {NAV.filter((n) => n.show(role)).map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} aria-current={path.startsWith(n.href) ? 'page' : undefined}
              className={`block rounded-md px-3 py-2 text-sm ${path.startsWith(n.href) ? 'bg-white/15' : 'text-white/70 hover:bg-white/10'}`}>{n.label}</Link>
          ))}
        </nav>
        <div className="border-t border-white/15 px-6 py-4 text-sm">
          <p className="truncate">{email}</p>
          <p className="text-white/60">{role}</p>
          <ThemeToggle />
          <button onClick={signOut} className="mt-2 text-white/80 underline">Sign out</button>
        </div>
      </aside>
    </>
  )
}
