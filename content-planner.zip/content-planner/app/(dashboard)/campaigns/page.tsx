import CampaignBoard from '@/components/CampaignBoard'
import { getContext } from '@/lib/org'
import { requirePlan } from '@/lib/billing/guard'
import { can } from '@/lib/permissions'
import type { Campaign } from '@/lib/types'

export default async function Campaigns() {
  const { supabase, org, role } = await getContext()
  await requirePlan(supabase, org.id, role)
  const { data } = await supabase.from('campaigns').select('id, name, channel, status, starts_on').eq('org_id', org.id).order('created_at', { ascending: false })
  return (
    <div>
      <h1 className="text-3xl font-semibold tracking-tight">Campaigns</h1>
      <CampaignBoard initial={(data ?? []) as Campaign[]} orgId={org.id} canEdit={can.editContent(role)} />
    </div>
  )
}
