import Link from 'next/link'
import Chart from '@/components/Chart'
import { getContext } from '@/lib/org'
import { can } from '@/lib/permissions'

const DAY = 864e5
function weekStart(d: Date) {
  const x = new Date(d); x.setUTCHours(0, 0, 0, 0)
  x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x
}

export default async function Overview() {
  const { supabase, org, role } = await getContext()
  const showLeads = can.viewLeads(role)
  const [camp, lead] = await Promise.all([
    supabase.from('campaigns').select('*', { count: 'exact', head: true }).eq('org_id', org.id).eq('status', 'active'),
    showLeads ? supabase.from('leads').select('status, created_at').eq('org_id', org.id) : null,
  ])
  const leads = lead?.data ?? []
  const converted = leads.filter((l) => l.status === 'converted').length
  const rate = leads.length ? Math.round((converted / leads.length) * 100) : 0

  const start = weekStart(new Date()).getTime()
  const data = Array.from({ length: 8 }, (_, i) => {
    const from = start - (7 - i) * 7 * DAY, to = from + 7 * DAY
    const inWeek = leads.filter((l) => { const t = new Date(l.created_at).getTime(); return t >= from && t < to })
    return {
      label: new Date(from).toLocaleDateString('en', { month: 'short', day: 'numeric', timeZone: 'UTC' }),
      leads: inWeek.length, converted: inWeek.filter((l) => l.status === 'converted').length,
    }
  })
  const kpis = [['Active campaigns', String(camp.count ?? 0)], ...(showLeads ? [['Total leads', String(leads.length)], ['Conversion rate', `${rate}%`]] : [])]

  return (
    <div className="max-w-4xl">
      <h1 className="text-3xl font-semibold tracking-tight">{org.name}</h1>
      {!!org.services?.length && <ul className="mt-3 flex flex-wrap gap-2" aria-label="Your Indigo services">{org.services.map((s) => <li key={s} className="rounded-full border border-line px-3 py-1 text-sm">{s}</li>)}</ul>}
      <dl className="mt-8 grid gap-4 sm:grid-cols-3">
        {kpis.map(([k, v]) => (
          <div key={k} className="rounded-lg border border-line bg-surface p-5 transition-shadow hover:shadow-md">
            <dt className="text-sm text-ink/70">{k}</dt>
            <dd className="mt-1 text-4xl font-semibold tabular-nums">{v}</dd>
          </div>
        ))}
      </dl>
      {showLeads && (
        <section className="mt-10" aria-labelledby="perf">
          <h2 id="perf" className="text-lg font-medium">Leads per week</h2>
          <p className="text-sm text-ink/70">Bars show new leads. The line shows how many converted.</p>
          {leads.length === 0
            ? <p className="mt-6 rounded-lg border border-dashed border-line p-8 text-center text-ink/70">No leads yet. <Link href="/leads" className="underline">Add your first lead</Link> to start tracking performance.</p>
            : <div className="mt-4 rounded-lg border border-line bg-surface p-4"><Chart data={data} /></div>}
        </section>
      )}
    </div>
  )
}
