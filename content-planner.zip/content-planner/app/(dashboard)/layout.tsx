import Sidebar from '@/components/Sidebar'
import { getContext } from '@/lib/org'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, org, role } = await getContext()
  return (
    <div className="min-h-screen lg:flex">
      <Sidebar orgName={org.name} role={role} email={user.email ?? ''} />
      <main className="min-w-0 flex-1 p-6 lg:p-12">{children}</main>
    </div>
  )
}
