export default function Loading() {
  return (
    <div className="max-w-3xl animate-pulse space-y-6" aria-busy="true" aria-label="Loading">
      <div className="h-9 w-56 rounded bg-line" />
      <div className="flex gap-4"><div className="h-24 flex-1 rounded-lg bg-line" /><div className="h-24 flex-1 rounded-lg bg-line" /><div className="h-24 flex-1 rounded-lg bg-line" /></div>
      <div className="h-56 rounded-lg bg-line" />
    </div>
  )
}
