import { redirect } from 'next/navigation'
import LeadsTable from '@/components/LeadsTable'
import { getContext } from '@/lib/org'
import { requirePlan } from '@/lib/billing/guard'
import { can } from '@/lib/permissions'
import type { Lead } from '@/lib/types'

export default async function Leads() {
  const { supabase, org, role } = await getContext()
  await requirePlan(supabase, org.id, role)
  if (!can.viewLeads(role)) redirect('/dashboard')
  const { data } = await supabase.from('leads').select('id, name, email, source, status, tags, created_at').eq('org_id', org.id).order('created_at', { ascending: false })
  return (
    <div className="max-w-5xl">
      <h1 className="text-3xl font-semibold tracking-tight">Leads</h1>
      <LeadsTable initial={(data ?? []) as Lead[]} orgId={org.id} canEdit={can.editContent(role)} />
    </div>
  )
}
