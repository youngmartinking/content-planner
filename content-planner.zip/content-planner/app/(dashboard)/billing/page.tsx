import { redirect } from 'next/navigation'
import { getContext } from '@/lib/org'
import { can } from '@/lib/permissions'
import { PLANS } from '@/lib/billing/plans'

export default async function Billing({ searchParams }: { searchParams: { paid?: string; error?: string } }) {
  const { supabase, org, role } = await getContext()
  if (!can.manageBilling(role)) redirect('/dashboard')
  const { data: sub } = await supabase.from('subscriptions').select('plan, status, current_period_end').eq('org_id', org.id).maybeSingle()
  const status = sub?.status ?? 'inactive'
  const name = PLANS.find((p) => p.key === sub?.plan)?.name ?? 'Your'
  const date = sub?.current_period_end ? new Date(sub.current_period_end).toLocaleDateString('en-GB', { dateStyle: 'long' }) : null
  const message: Record<string, string> = {
    active: `${name} plan is active${date ? ` until ${date}` : ''}. To change or cancel it, contact Indigo on 0556919967.`,
    past_due: 'Your last payment failed. Contact Indigo on 0556919967 or choose a plan below to pay again.',
    cancelled: 'Your plan was cancelled. Choose a plan to start again.',
    inactive: 'You don’t have a plan yet. Choose one to get started.',
  }

  return (
    <div className="max-w-4xl">
      <h1 className="text-3xl font-semibold tracking-tight">Billing</h1>
      <p className="mt-2 text-ink/80">{message[status]}</p>
      {searchParams.paid && status !== 'active' && <p role="status" className="mt-4 rounded-md border border-line bg-surface p-3 text-sm">Payment received. Your plan switches on once Paystack confirms it, usually within a minute. Refresh this page to check.</p>}
      {searchParams.error && <p role="alert" className="err">{searchParams.error}</p>}
      {status !== 'active' && (
        <ul className="mt-8 grid gap-4 sm:grid-cols-3">
          {PLANS.map((p) => (
            <li key={p.key} className="flex flex-col rounded-lg border border-line bg-surface p-5">
              <h2 className="text-lg font-medium">{p.name}</h2>
              <p className="mt-1 text-3xl font-semibold tabular-nums">{p.currency} {p.price.toLocaleString('en-GH')}<span className="text-base font-normal text-ink/70"> / month</span></p>
              <p className="mt-2 flex-1 text-sm text-ink/70">{p.blurb}</p>
              <form method="post" action="/api/billing/checkout" className="mt-4">
                <input type="hidden" name="plan" value={p.key} />
                <button className="btn w-full">Subscribe with Paystack</button>
              </form>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
