import PostEditor from '@/components/PostEditor'
import { getContext } from '@/lib/org'
import { requirePlan } from '@/lib/billing/guard'
import { can } from '@/lib/permissions'
import type { Post } from '@/lib/types'

export default async function Content() {
  const { supabase, org, role } = await getContext()
  await requirePlan(supabase, org.id, role)
  const [posts, camps] = await Promise.all([
    supabase.from('posts').select('id, title, body, channel, status, scheduled_at, campaign_id').eq('org_id', org.id).order('created_at', { ascending: false }),
    supabase.from('campaigns').select('id, name').eq('org_id', org.id).order('name'),
  ])
  return (
    <div className="max-w-5xl">
      <h1 className="text-3xl font-semibold tracking-tight">Content</h1>
      <PostEditor initial={(posts.data ?? []) as Post[]} campaigns={camps.data ?? []} orgId={org.id} canEdit={can.editContent(role)} />
    </div>
  )
}
