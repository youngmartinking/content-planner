import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { PLANS } from '@/lib/billing/plans'
import { provider } from '@/lib/billing/provider'

export async function POST(req: Request) {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? new URL(req.url).origin
  const back = (msg: string) => NextResponse.redirect(`${base}/billing?error=${encodeURIComponent(msg)}`, 303)
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.redirect(`${base}/login`, 303)

  const { data: m } = await supabase.from('memberships').select('org_id, role').eq('user_id', user.id).limit(1).maybeSingle()
  if (!m || m.role !== 'admin') return back('Only admins can manage billing.')
  const plan = PLANS.find((p) => p.key === String((await req.formData()).get('plan')))
  if (!plan) return back('Choose a plan.')
  try {
    const url = await provider.checkout({ email: user.email!, plan, orgId: m.org_id, callbackUrl: `${base}/billing?paid=1` })
    return NextResponse.redirect(url, 303)
  } catch (e) {
    console.error('checkout failed', e)
    return back('Payment could not be started. Please try again.')
  }
}
