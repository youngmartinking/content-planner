import crypto from 'crypto'
import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { PLANS } from '@/lib/billing/plans'

export const runtime = 'nodejs'
const MONTH = 30 * 864e5

// Paystack calls this after payments. Subscription state is only ever changed here, after the signature check.
export async function POST(req: Request) {
  const raw = await req.text()
  const sig = Buffer.from(req.headers.get('x-paystack-signature') ?? '')
  const want = Buffer.from(crypto.createHmac('sha512', process.env.PAYSTACK_SECRET_KEY!).update(raw).digest('hex'))
  if (sig.length !== want.length || !crypto.timingSafeEqual(sig, want)) return new NextResponse('Invalid signature', { status: 401 })

  const { event, data } = JSON.parse(raw)
  const db = createAdminClient()
  const customer: string | undefined = data?.customer?.customer_code
  const now = new Date().toISOString()
  const byCustomer = (patch: Record<string, unknown>) =>
    db.from('subscriptions').update({ ...patch, updated_at: now }).eq('provider_customer', customer ?? '')
  let query: PromiseLike<{ error: unknown }> | null = null

  if (event === 'charge.success') {
    const plan = PLANS.find((p) => p.key === data.metadata?.plan)
    const periodEnd = new Date(Date.now() + MONTH).toISOString()
    if (data.metadata?.org_id && plan) {
      if (data.amount !== plan.price * 100 || data.currency !== plan.currency) {
        console.error('Paystack amount does not match plan', plan.key, data.amount, data.currency)
        return NextResponse.json({ ignored: true })
      }
      query = db.from('subscriptions').upsert({
        org_id: data.metadata.org_id, plan: plan.key, status: 'active', provider: 'paystack',
        provider_customer: customer, current_period_end: periodEnd, updated_at: now,
      })
    } else if (customer) {
      query = byCustomer({ status: 'active', current_period_end: periodEnd })
    }
  } else if (event === 'subscription.create' && customer) {
    query = byCustomer({ provider_subscription: data.subscription_code, current_period_end: data.next_payment_date })
  } else if (event === 'invoice.payment_failed' && customer) {
    query = byCustomer({ status: 'past_due' })
  } else if (event === 'subscription.disable' && customer) {
    query = byCustomer({ status: 'cancelled' })
  }

  const error = query ? (await query).error : null
  // A 500 makes Paystack retry later.
  return error ? new NextResponse('Database error', { status: 500 }) : NextResponse.json({ ok: true })
}
