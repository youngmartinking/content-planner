import './globals.css'
import { Bricolage_Grotesque } from 'next/font/google'

const font = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-sans' })
const THEME = "try{var t=localStorage.theme;if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}"
export const metadata = { title: 'Indigo Workspace', description: 'One monthly plan for your brand, handle, PR, design, video and web.' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={font.variable} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: THEME }} /></head>
      <body className="bg-paper font-sans text-ink antialiased">{children}</body>
    </html>
  )
}
