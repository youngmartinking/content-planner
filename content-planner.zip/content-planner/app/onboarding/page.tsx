'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { SERVICES } from '@/lib/types'
import { createClient } from '@/lib/supabase/client'

const INDUSTRIES = ['E-commerce', 'SaaS', 'Agency', 'Health & wellness', 'Real estate', 'Education', 'Food & drink', 'Other']
const VOICES = ['Professional', 'Friendly', 'Bold', 'Playful', 'Luxury', 'Educational']
const TITLES = ['What’s your company called?', 'Which industry are you in?', 'Who is your audience?', 'How should your brand sound?', 'Which Indigo services do you need?']

export default function Onboarding() {
  const router = useRouter()
  const supabase = createClient()
  const [step, setStep] = useState(0)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [services, setServices] = useState<string[]>([])
  const [f, setF] = useState({ name: '', industry: '', audience: '', voice: '' })
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v })
  const valid = [f.name.trim(), f.industry, f.audience.trim(), f.voice, services.length][step]

  async function finish() {
    setBusy(true); setErr('')
    const { error } = await supabase.rpc('create_organization', {
      p_name: f.name.trim(), p_industry: f.industry, p_audience: f.audience.trim(), p_voice: f.voice, p_services: services,
    })
    if (error) { setErr(error.message); setBusy(false); return }
    router.push('/dashboard'); router.refresh()
  }
  const chips = (opts: string[], key: keyof typeof f) => (
    <div className="flex flex-wrap gap-2">
      {opts.map((o) => (
        <button key={o} type="button" aria-pressed={f[key] === o} onClick={() => set(key)(o)}
          className={`rounded-full border px-4 py-2 text-sm ${f[key] === o ? 'border-leaf bg-leaf text-onleaf' : 'border-line bg-surface hover:border-leaf'}`}>{o}</button>
      ))}
    </div>
  )

  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6 py-10">
      <div className="h-1 rounded bg-line"><div className="h-1 rounded bg-leaf transition-all" style={{ width: `${((step + 1) / TITLES.length) * 100}%` }} /></div>
      <p className="mt-3 text-sm text-ink/60">Step {step + 1} of {TITLES.length}</p>
      <h1 className="mt-6 text-3xl font-semibold tracking-tight">{TITLES[step]}</h1>
      <div className="mt-6">
        {step === 0 && <input className="input" autoFocus placeholder="Acme Studio" value={f.name} onChange={(e) => set('name')(e.target.value)} />}
        {step === 1 && chips(INDUSTRIES, 'industry')}
        {step === 2 && <textarea className="input" rows={4} placeholder="Who are you trying to reach? Their roles, ages and the problems they have." value={f.audience} onChange={(e) => set('audience')(e.target.value)} />}
        {step === 3 && chips(VOICES, 'voice')}
        {step === 4 && (
          <div className="flex flex-wrap gap-2">
            {SERVICES.map((s) => {
              const on = services.includes(s)
              return <button key={s} type="button" aria-pressed={on} onClick={() => setServices(on ? services.filter((x) => x !== s) : [...services, s])}
                className={`rounded-full border px-4 py-2 text-sm ${on ? 'border-leaf bg-leaf text-onleaf' : 'border-line bg-surface hover:border-leaf'}`}>{s}</button>
            })}
          </div>
        )}
      </div>
      {err && <p role="alert" className="mt-4 text-sm text-red-700">{err}</p>}
      <div className="mt-8 flex justify-between">
        <button className="btn-ghost" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</button>
        {step < TITLES.length - 1
          ? <button className="btn" disabled={!valid} onClick={() => setStep(step + 1)}>Continue</button>
          : <button className="btn" disabled={!valid || busy} onClick={finish}>Create workspace</button>}
      </div>
    </main>
  )
}
