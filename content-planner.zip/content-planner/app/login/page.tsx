'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Logo from '@/components/Logo'
import { SERVICES } from '@/lib/types'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const supabase = createClient()
  const router = useRouter()
  const [mode, setMode] = useState<'in' | 'up'>('in')
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  const callback = () => `${location.origin}/auth/callback`

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg('')
    const d = new FormData(e.currentTarget)
    const creds = { email: String(d.get('email')), password: String(d.get('password')) }
    const { data, error } = mode === 'in'
      ? await supabase.auth.signInWithPassword(creds)
      : await supabase.auth.signUp({ ...creds, options: { emailRedirectTo: callback(), data: { full_name: String(d.get('name') ?? '') } } })
    setBusy(false)
    if (error) return setMsg(error.message)
    if (mode === 'up' && !data.session) return setMsg('Check your email to confirm your account.')
    router.push('/dashboard'); router.refresh()
  }
  const google = () => supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: callback() } })

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-2">
      <aside className="hidden flex-col justify-between bg-pine p-12 text-white lg:flex">
        <Logo className="h-14" />
        <div>
          <p className="max-w-sm text-4xl font-semibold leading-tight tracking-tight">Need visibility? Let’s build your brand.</p>
          <ul className="mt-6 space-y-1 text-white/80">{SERVICES.map((s) => <li key={s}>{s}</li>)}</ul>
        </div>
        <p className="text-sm text-white/70">www.indigo.io<br />0556919967</p>
      </aside>
      <main className="flex items-center justify-center px-6 py-12">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <Logo className="h-10 text-pine dark:text-white lg:hidden" />
          <h1 className="text-2xl font-semibold tracking-tight">{mode === 'in' ? 'Sign in' : 'Create your account'}</h1>
          <button type="button" onClick={google} className="btn-ghost w-full">Continue with Google</button>
          {mode === 'up' && <input name="name" className="input" placeholder="Full name" autoComplete="name" required />}
          <input name="email" type="email" className="input" placeholder="Email" autoComplete="email" required />
          <input name="password" type="password" className="input" placeholder="Password (8+ characters)" minLength={8}
            autoComplete={mode === 'in' ? 'current-password' : 'new-password'} required />
          {msg && <p role="alert" className="text-sm text-red-700">{msg}</p>}
          <button className="btn w-full" disabled={busy}>{mode === 'in' ? 'Sign in' : 'Create account'}</button>
          <button type="button" className="text-sm underline" onClick={() => { setMode(mode === 'in' ? 'up' : 'in'); setMsg('') }}>
            {mode === 'in' ? 'New here? Create an account' : 'Have an account? Sign in'}
          </button>
        </form>
      </main>
    </div>
  )
}
